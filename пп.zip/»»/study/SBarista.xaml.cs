﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace study
{
    public partial class SBarista : Window
    {
        private DataBase _database;
        public SBarista()
        {
            InitializeComponent();
            FillListView();
            _database = new DataBase();
            LoadData();
        }

        private void FillListView()
        {
            DataBase db = new DataBase();
            DataSet dataSet = db.GetDataFromDb();

            courseListView1.ItemsSource = dataSet.Tables["Schedule"].DefaultView;
            listView.ItemsSource = dataSet.Tables["Tovars"].DefaultView;

        }

        private void LoadData()
        {
            DataSet dataSet = _database.GetDataFromDb();
            courseListView1.ItemsSource = dataSet.Tables["Schedule"].DefaultView;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string dat = TextBoxDate.Text;
            string eur = TextBoxEurope.Text;
            string gal = TextBoxGalaxy.Text;
            string alpha = TextBoxAlpha.Text;
            if (string.IsNullOrWhiteSpace(dat) ||
                string.IsNullOrWhiteSpace(eur) || string.IsNullOrWhiteSpace(gal) || string.IsNullOrWhiteSpace(alpha))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            DataBase db = new DataBase();
            db.AddCourse(dat, eur, gal, alpha);
            LoadData();
        }
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            textBox.Text = string.Empty;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string del = TextBoxDelivery.Text;
            string date = TextBoxDate.Text;
            string status = TextBoxStatus.Text;
            string shop = TextBoxNameshop.Text;
            if (string.IsNullOrWhiteSpace(del) ||
                string.IsNullOrWhiteSpace(date) || string.IsNullOrWhiteSpace(status) || string.IsNullOrWhiteSpace(shop))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            DataBase db = new DataBase();
            db.AddTovars(del, date, status, shop);
            LoadData();
        }

        private void courseListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
