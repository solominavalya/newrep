﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace study
{
    public class  DueDate
    {
        public int Id { get; set; }
        public string NameWork { get; set; }
        public string Course { get; set; }
        public string Descriptionofwork { get; set; }
        public int Duedatesofwork { get; set; }
    }
}
