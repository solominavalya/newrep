﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace study
{
    /// <summary>
    /// Логика взаимодействия для Barista.xaml
    /// </summary>
    public partial class Barista : Window
    {
        private DataBase _database;
        public Barista()
        {
            InitializeComponent();
            FillListView();
        }

        private void FillListView()
        {
            DataBase db = new DataBase();
            DataSet dataSet = db.GetDataFromDb();

            courseListView1.ItemsSource = dataSet.Tables["Schedule"].DefaultView;
            listView.ItemsSource = dataSet.Tables["Tovars"].DefaultView;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.ShowDialog();
        }

        private void courseListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
