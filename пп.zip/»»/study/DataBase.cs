﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace study
{
    public class DataBase
    {
       
        public User AuthenticateUser(string Login, string Password, string Role)
        {
            using (var connection = new SqlConnection(_connectionString))
            {

                try
                {
                    {
                        connection.Open();
                        string query = "SELECT * FROM Users WHERE Login = @Login AND Password = @Password  AND Role = @Role";
                        using (var command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Login", Login);
                            command.Parameters.AddWithValue("@Password", Password);
                            command.Parameters.AddWithValue("@Role", Role);

                            using (var reader = command.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    return new User
                                    {
                                        Id = reader.GetInt32(0),
                                        Login = reader.GetString(1),
                                        Password = reader.GetString(2),
                                       
                                        Role = reader.GetString(3)
                                    };
                                }
                                else
                                {
                                    return null;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return null;
                }
            }
        }
        public DataSet GetDataFromDb()
        {

            string connectionString = @"Server=LAPTOP-HV9AOUAU\SQLEXPRESS;Database=coffebull;TrustServerCertificate=True;Trusted_Connection=true;";

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            string query1 = "SELECT * FROM Schedule";
            string query2 = "SELECT * FROM Tovars";
          

            SqlCommand command1 = new SqlCommand(query1, connection);
            SqlCommand command2 = new SqlCommand(query2, connection);


            SqlDataAdapter adapter1 = new SqlDataAdapter(command1);
            SqlDataAdapter adapter2 = new SqlDataAdapter(command2);
         

            DataSet dataSet = new DataSet();

            adapter1.Fill(dataSet, "Schedule");
            adapter2.Fill(dataSet, "Tovars");
            
    

            return dataSet;

        }
       
        private const string _connectionString = @"Data Source=LAPTOP-HV9AOUAU\SQLEXPRESS;Initial Catalog=coffebull;Integrated Security=True";
        private static SqlConnection connectionSql = new SqlConnection(_connectionString);


   
        public static bool Registration(string login, string password,string role)
        {
            connectionSql.Open();
            
            string selectNamePass = $"SELECT Login FROM Users WHERE Login='{login}';";
            string insertNewUser = $"INSERT INTO Users ( Login, Password, Role) VALUES ( '{login}', '{password}', '{role}');";
            SqlCommand command = new SqlCommand(selectNamePass, connectionSql);
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    connectionSql.Close();
                    return false;
                }
            }
            (new SqlCommand(insertNewUser, connectionSql)).ExecuteNonQuery();
            connectionSql.Close();
            return true;
        }

        public void AddCourse( string date, string europe, string galaxy, string alpha)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Schedule ( Date, Europe, Galaxy, Alpha) VALUES (@Date, @Europe, @Galaxy,@Alpha)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                   
                    command.Parameters.AddWithValue("@date", date);
                    command.Parameters.AddWithValue("@europe", europe);
                    command.Parameters.AddWithValue("@galaxy", galaxy);
                    command.Parameters.AddWithValue("@Alpha", alpha);
                    command.ExecuteNonQuery();
                }
            }
        }
        public void AddTovars(string delivery, string date, string status, string nameShop)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Tovars ( Delivery, Date, Status, NameShop) VALUES (@Delivery, @Date, @Status,@NameShop)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@Delivery", delivery);
                    command.Parameters.AddWithValue("@Date", date);
                    command.Parameters.AddWithValue("@Status", status);
                    command.Parameters.AddWithValue("@NameShop", nameShop);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
