﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace study
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = textBoxLogin.Text;
            string password = GetPassword();
       
            string role = RoleComboBox.Text.ToString();

            var dateBase = new DataBase();
            var user = dateBase.AuthenticateUser(login, password, role);
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if(user!=null)
            {
                if (role == "St.Barista")
                {
                    SBarista sbarista = new SBarista();
                    sbarista.Show();
                }
                else if (role == "Barista")
                {
                    Barista barista = new Barista();
                    barista.Show();
                }
          
            }
            else
            {

                MessageBox.Show("Неправильный логин, пароль или роль");
            }
            this.Close();
        }


        private void ButtonRegA_Click(object sender, RoutedEventArgs e)
        {
            Registr registration = new Registr();
            registration.Show();
            Hide();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_1TextChanged(object sender, TextChangedEventArgs e)
        {

        }

  
        private void ShowPassword_Checked1(object sender, RoutedEventArgs e)
        {
            
            PasswordBox.Visibility = Visibility.Collapsed;
            textBoxPass.Text = PasswordBox.Password;
            textBoxPass.Visibility = Visibility.Visible;
         
        }
        private void ShowPassword_Unchecked1(object sender, RoutedEventArgs e)
        {
            textBoxPass.Visibility = Visibility.Collapsed;
            PasswordBox.Visibility = Visibility.Visible;
        }
        private string GetPassword()
        {
            if (PasswordBox.Visibility == Visibility.Visible)
            {
                return PasswordBox.Password;
            }
            else
            {
                return textBoxPass.Text;
            }
        }
        private void RoleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          
        }
    }
}
